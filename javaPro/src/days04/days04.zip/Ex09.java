package days04;

/**
 * @author kenik
 * @date 2025. 2. 6. - 오후 5:26:37
 * @subject  조건반복문 : while문, do~while문
 * @content
 */
public class Ex09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
