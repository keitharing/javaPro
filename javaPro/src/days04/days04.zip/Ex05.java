package days04;

/**
 * @author kenik
 * @date 2025. 2. 6. - 오후 2:10:00
 * @subject 
 * @content
 */
public class Ex05 {

	public static void main(String[] args) {
		/*
		 * [제어문]
		 * 1. 정의 : 프로그램의 실행 순서(흐름)를 제어하는 문
		 * 2. 종류
		 *   1) 조건문 : if문            				Ex06.java
		 *   2) 분기문 : switch문        				Ex07.java
		 *   3) 반복문 : for문    확장for문(foreach문)  Ex08.java
		 *   4) 조건반복문 : while문,   do~while문  	Ex09.java
		 *   5) 기타  : break문, continue문
		 * */

	} // main

} // class
