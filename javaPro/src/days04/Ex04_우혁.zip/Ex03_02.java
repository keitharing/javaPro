package days04;

public class Ex03_02 {

	public static void main(String[] args) {
		
		//학생의 이름을 여러명 저장 -> 배열 선언
		String [] names = null;	//배열선언 - 참조변수, 배열명, 지역변수
		names = new String[100];
		names[0] = "홍길동";
		names[1] = "이창익";
		
		//java.lang.NullPointerException - 오류메세지가 뜸
		System.out.println( names[0]);
		System.out.println( names[10]);
		
		
		
	}
	
}
