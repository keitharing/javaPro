package days04;

import java.util.Scanner;

/**
 * @author kenik
 * @date 2025. 2. 6. - 오후 3:33:53
 * @subject 
 * @content
 */
public class Ex06_03 {
   
   public static void main(String[] args) {

      int kor ;       
      Scanner scanner = new Scanner(System.in);
      System.out.print("> 국어 점수 입력 ? ");
      kor = scanner.nextInt();
      
      if ( 0 <= kor && kor <= 100 ) {

         if ( 90 <= kor && kor <= 100 ) {
            System.out.println("수");
         } // if
         if ( 80 <= kor && kor <= 89 ) {
            System.out.println("우");
         } // if
         if ( 70 <= kor && kor <= 79  ) {
            System.out.println("미");
         } // if
         if ( 60 <= kor && kor <= 69 ) {
            System.out.println("양");
         } // if
         if ( 0 <= kor && kor <= 59 ) {
            System.out.println("가");
         } // if
      } else {
         System.out.println("[알림] 국어 점수 0~100 !!!");
      } // if
      
      
      
      
      System.out.println(" end ");
   } // main

} // class








