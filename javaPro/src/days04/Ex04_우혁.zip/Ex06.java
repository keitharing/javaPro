package days04;

import java.util.Scanner;
import java.util.concurrent.locks.Condition;

/**
 * @author user
 * @date 2025. 2. 6. - 오후 2:16:11
 * @subject	조건문 : if문
 * @content	
 */
public class Ex06 {

public static void main(String[] args) {
	
	int n;
	Scanner sc = new Scanner(System.in);
	System.out.println("> 정수(n)>입력?");
	n = sc.nextInt(); 
	
	
	
	if ( n>10 ) {
		
		System.out.println("출력O");
		
		
	} //if
	
	
		System.out.println("end");
	
	
	
	}//main

}//class
