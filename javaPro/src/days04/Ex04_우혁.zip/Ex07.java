package days04;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		
		// [문제]
		//정수를 입력받아서 "홀수"/"짝수" 라고 출력
		
		int n;			
		Scanner sc = new Scanner(System.in);
		System.out.print("> 정수(n)>입력?");
		n = sc.nextInt(); 
		
		String result = null;
		switch (n%2) {
		case 0:
			//System.out.println("짝수(Even Number)");
			result = "짝수(Even Number)";
			break;
		case 1:
			//System.out.println("홀수(Odd Number)");
			result = "홀수(Odd Number)";
			break;
		}//switch
		
		
		

	}//main

}
/*
switch (key) {
case value:
	
	break;

[default:
	break;]
}//switch
*/