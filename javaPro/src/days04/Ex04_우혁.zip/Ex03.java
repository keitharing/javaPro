package days04;

/**
 * @author user
 * @date 2025. 2. 6. - 오전 11:19:54
 * @subject	[문제] 연산자
 * @content		[] 도 인덱스(index)연산자
 */
public class Ex03 {

	public static void main(String[] args) { //String 배열 args
			//한 학생의 국어점수를 저장할 변수를 선언.
			int kor = 0; //이때까지는 이렇게 하였음
			//100명 학생의 국어점수를 저장할 변수를 선언.
			/*
			int kor001;
			int kor001;
			int kor001;
			.
			.
			int kor100;
			*/
			//동일한 자료형을 메모리상에 연속적으로 놓이게 한 것 = 배열(arrey)
			// ㄴ 참조형
			//2. 배열 선언 및 생성 형식
			// 자료형 [](대괄호) 배열명;
			// new 자료형[배열크기];
			//LowerBound(아랫첨자값)은 항상 0에서 시작
			//UpperBound(윗첨자값)은 배열크기 - 1
			int [] kors; // int 배열 kors 
			kors = new int[100]; // int = 4바이트가 100개가 잡힌다~
			// 배열 크기
			// 배열명.length
			int size = kors.length;
			System.out.println(size);
			
			//첫번째 방에다가 90점 두번째 방에다가 67점주기
			kors [0] = 90;
			kors [1] = 67;
			
			System.out.println( kors [0]);
			System.out.println( kors [1]);
			
			
			
			/*
			 * 		heap						stack
			 * 		[4]							[주소값]
			 * 		0x100						
			 * 		시작주소						
			 * 									[0x100]
			 * 									kors 변수, 참조변수, 배열명
			 * *
			 */
			
		
		

	}

}
