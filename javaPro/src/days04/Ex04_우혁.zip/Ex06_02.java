package days04;

import java.util.Scanner;
import java.util.concurrent.locks.Condition;

/**
 * @author user
 * @date 2025. 2. 6. - 오후 2:16:11
 * @subject	조건문 : if문
 * @content	
 */
public class Ex06_02 {

public static void main(String[] args) {
	// [문제]
	// 정수를 입력받아서 "홀수"/"짝수" 라고 출력
	
	int n;
	// Resource leak: 'scanner' is never closed
	@SuppressWarnings("resource")			//@어노테이션
	Scanner sc = new Scanner(System.in);
	System.out.println("> 정수(n)>입력?"); // Ctrl + Shift + B = break point(여기까지 디버깅 잡기위해서)
	n = sc.nextInt(); 
	
	/*
	if(n%2 == 0) {
		
		System.out.println("짝수(Even Number)");
		
	}
	/*
	if(n%2 != 0) {
		
		System.out.println("홀수(Odd Number)");
		
	}
	*/
	
	if (n%2 == 0) {
			
		System.out.println("짝수(Even Number)");
		
	} else {
		
		System.out.println("홀수(Odd Number)");	
	}
	
	System.out.println("end");
	
	
	
	}//main

}//class
