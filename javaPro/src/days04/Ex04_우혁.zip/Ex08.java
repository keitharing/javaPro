package days04;

/**
 * @author user
 * @date 2025. 2. 6. - 오후 5:27:11
 * @subject
 * @content	for/ foreach 반복
 */
public class Ex08 {

	public static void main(String[] args) {
		
		for (int i = 0; i < 50; i++) {
			System.out.println("이창익");
		} //for i
		
		
		
		
		
		
		
		
	}//main

}//class
