package days04;

import java.util.Scanner;

public class Ex07_02 {

	public static void main(String[] args) {
	      int kor = -1 ;       
	      Scanner scanner = new Scanner(System.in);
	      System.out.print("> 국어 점수 입력 ? ");  
	       
	      if (!scanner.hasNextInt()) {
	         System.out.println("[알림] 국어 점수 0~100 !!!");
	         return ;
	      } // if
	    
	      kor = scanner.nextInt();   
	      char grade = '수'; 
	      
	     
	 
		}//switch
	      	
	       
	      
	      
	      
	      
	      
	      
	      

	}//main

}//class
