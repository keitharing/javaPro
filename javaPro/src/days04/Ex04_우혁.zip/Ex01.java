package days04;

public class Ex01 {

	public static void main(String[] args) {
		//연산자 : instanceof 연산자
		//		>>	>>>	<< 쉬프트(shift)연산자
		//					방향을 바꾸다, 이동시키다, 옮기다.
		//		>>=		<<=	복합대입연산자.
		
		
		System.out.println( 15 >> 2);	//15 = 00001111 -> >> _ _000011 = 3
		System.out.println( 15 >>> 2);
		System.out.println( 15 << 2);	// 00111100 = 60
		
		// 00001111
		String b = Integer.toBinaryString(15);
		
		System.out.println(Integer.toBinaryString(15));
		System.out.printf("%08d", Integer.parseInt(b));	//00001111
		
		
		/*
		String binaryString = Integer.toBinaryString(15);
		String paddedBinary = String.format("%8s", binaryString).replace(' ', '0');
		System.out.println(paddedBinary);
		*/ //Ai 답변
		
		System.out.println(Integer.toOctalString(15));	//8진수 문자열
		System.out.println(Integer.toHexString(15));	//16진수 문자열
		
		
	}//main

}//class
