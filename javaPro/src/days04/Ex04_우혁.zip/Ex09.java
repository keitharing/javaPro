package days04;

/**
 * @author user
 * @date 2025. 2. 6. - 오후 5:27:30
 * @subject
 * @content	while문 조건반복문
 */
public class Ex09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
