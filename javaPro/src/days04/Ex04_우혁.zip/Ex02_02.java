package days04;

public class Ex02_02 {

	public static void main(String[] args) {
		// 두 문자열을 비교할때는 String.equals() 메서드 사용
		String n1 = "홍길동";
		String n2 = "홍길동";
		
		System.out.println( n1 == n2); //True가 나오면 안되는데 
		System.out.println(n1.equals(n2));
		
		
		
	}

}
